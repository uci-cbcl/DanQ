========
Usage
========

To use Seya in a project::

    import seya
