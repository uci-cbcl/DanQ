============
Installation
============

At the command line::

    $ easy_install seya

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv seya
    $ pip install seya
