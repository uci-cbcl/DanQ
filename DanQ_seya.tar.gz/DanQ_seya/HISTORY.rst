.. :changelog:

History
-------

0.1.0 (2015-07-07)
---------------------

* First release on PyPI.
