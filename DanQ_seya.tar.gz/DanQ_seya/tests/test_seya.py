#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
test_seya
----------------------------------

Tests for `seya` module.
"""

import unittest

from seya import seya


class TestSeya(unittest.TestCase):

    def setUp(self):
        pass

    def test_something(self):
        pass

    def tearDown(self):
        pass

if __name__ == '__main__':
    unittest.main()
